//: Playground - noun: a place where people can play

import Foundation

prefix func -(c1: ComplexNumber) -> ComplexNumber {
  return c1.reflection()
}

func +(c1: ComplexNumber, c2: ComplexNumber) -> ComplexNumber {
  return c1.add(c2)
}

func -(c1: ComplexNumber, c2: ComplexNumber) -> ComplexNumber {
  return c1.subtract(c2)
}

func *(c1: ComplexNumber, c2: ComplexNumber) -> ComplexNumber {
  return c1.multiply(c2)
}

func *(c1: ComplexNumber, factor: Double) -> ComplexNumber {
  return c1.multiply(factor)
}

func /(c1: ComplexNumber, c2: ComplexNumber) -> ComplexNumber {
  return c1.divide(c2)
}

func /(c1: ComplexNumber, factor: Double) -> ComplexNumber {
  return c1.divide(factor)
}

struct ComplexNumber: CustomStringConvertible {
  static var NaN: ComplexNumber = ComplexNumber(re: Double.NaN, im: Double.NaN)
  var re: Double = 0
  var im: Double = 0
  
  init() {
    self.re = 0
    self.im = 0
  }
  
  init(re: Double, im: Double) {
    self.re = re
    self.im = im
  }
  
  var description: String {
    if self.isNaN() {
      return "C{NaN}"
    }
    
    if im == 0 {
      return "R{\(re)}"
    }
    
    let imSign = im > 0 ? "+" : "-"
    return "C{\(re) \(imSign) \(abs(im))i}"
  }
  
  func modulus() -> Double {
    return sqrt(pow(re, 2) + pow(im, 2))
  }
  
  func argument() -> (Double, Double) {
    return (re, im)
  }
  
  func isNaN() -> Bool {
    return re.isNaN || im.isNaN
  }
  
  func isZero() -> Bool {
    return re == 0 && im == 0
  }
  
  func reflection() -> ComplexNumber {
    var ref = self
    ref.im = -self.im
    return ref
  }
  
  func reciprocal() -> ComplexNumber {
    if self.isZero() {
      return ComplexNumber.NaN
    }
    
    var rec = ComplexNumber()
    let sumOfSquares = pow(self.re, 2) + pow(self.im, 2)
    rec.re = self.re / sumOfSquares
    rec.im = self.im / sumOfSquares
    return rec
  }
  
  func add(otherNumber: ComplexNumber) -> ComplexNumber {
    var result = self
    result.re += otherNumber.re
    result.im += otherNumber.im
    return result
  }
  
  func subtract(otherNumber: ComplexNumber) -> ComplexNumber {
    var result = self
    result.re -= otherNumber.re
    result.im -= otherNumber.im
    return result
  }
  
  func multiply(otherNumber: ComplexNumber) -> ComplexNumber {
    var result = ComplexNumber()
    result.re = self.re * otherNumber.re - self.im * otherNumber.im
    result.im = self.re * otherNumber.im + self.im * otherNumber.re
    return result
  }
  
  func divide(otherNumber: ComplexNumber) -> ComplexNumber {
    if otherNumber.isZero() {
      return ComplexNumber.NaN
    }
    
    var result = ComplexNumber()
    
    let sumOfSquares = pow(otherNumber.im, 2) + pow(otherNumber.im, 2)
    result.re = (self.re*otherNumber.re + self.im*otherNumber.im) / sumOfSquares
    result.im = (self.im*otherNumber.re - self.re*otherNumber.im) / sumOfSquares
    return result
  }
  
  func multiply(factor: Double) -> ComplexNumber {
    var result = self
    result.re *= factor
    result.im *= factor
    return result
  }
  
  func divide(factor: Double) -> ComplexNumber {
    if factor == 0 {
      return ComplexNumber.NaN
    }
    
    var result = self
    result.re /= factor
    result.im /= factor
    return result
  }
  
  func dividedBy(factor: Double) -> ComplexNumber {
    if self.isZero() {
      return ComplexNumber.NaN
    }
    
    var result = self.reciprocal()
    result = result.multiply(factor)
    return result
  }
}

let c0 = ComplexNumber()
let c1 = ComplexNumber(re: 1, im: 3)
let c2 = ComplexNumber(re: 2, im: -4)

print(c1)
"Complex number 2: \(c2)"

c1.modulus()
c1.argument()
c1

c2.modulus()
c2

let c4 = -c1
c1 * c4
c1 + c2
c1 - c2
c1 * c2
c1 / c2
c1 / c0
c1 * 3
c2 / 5