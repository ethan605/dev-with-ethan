//: Playground - noun: a place where people can play

import Foundation

func max(number1: Int, _ number2: Int) -> Int {
  return number1 > number2 ? number1 : number2
}

func max(number1: Double, _ number2: Double) -> Double {
  return number1 > number2 ? number1 : number2
}

max(1, 2)
max(1.5, 2.8)

func genericsMax<T: Comparable>(number1: T, _ number2: T) -> T {
  if T.self == Double.self {
    print("Compare Double numbers \(number1) & \(number2)")
  }
  
  return number1 > number2 ? number1 : number2
}

genericsMax(1, 2)
genericsMax(1.5, 2.8)
genericsMax("1", "2")

//genericsMax(1, 2) as Double
//genericsMax(Double(1), Double(2))

class Base: NSObject {
  required override init() {}
  
  class func announce() -> String {
    let classType = NSStringFromClass(self)
    let className = classType.componentsSeparatedByString(".").last!
    return "Using class \(className)"
  }
  
  func greet() -> String {
    let classType = NSStringFromClass(self.dynamicType)
    let className = classType.componentsSeparatedByString(".").last!
    return "Hi, I'm a \(className)"
  }
}

class Person: Base {
}

class Animal: Base {
}

Base.announce()
Person.announce()
Animal.announce()

Base().greet()
Person().greet()
Animal().greet()

func objectGreeting<T: Base>(classType: T.Type) -> String {
  print(T.announce())
  return classType.init().greet()
}

objectGreeting(Base.self)
objectGreeting(Person.self)
objectGreeting(Animal.self)
