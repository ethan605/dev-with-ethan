//
//  ViewController.swift
//  gcd-demo
//
//  Created by Ethan Nguyen on 8/2/16.
//  Copyright © 2016 Thanh Nguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  override func viewDidLoad() {
    super.viewDidLoad()
    self.backgroundThread()
    self.mutualDataWithoutMutex()
    self.mutualDataWithMutex()
    self.performWithDelay()
    self.queuedTasks()
  }
  
  private func backgroundThread() {
    print("\nDemo background threads")
    func A() { print("A") }
    func B() { var i = 1.0; for _ in 0..<10_000 { i *= 2 }; print("B") }
    func C() { print("C") }
    func D() { print("D") }
    
    let priority = DISPATCH_QUEUE_PRIORITY_DEFAULT
    let backgroundThread = dispatch_get_global_queue(priority, 0)
    
    A()
    dispatch_async(backgroundThread) { B() }
    C()
    D()
  }
  
  private func mutualDataWithoutMutex() {
    print("\nDemo mutual data without mutex")
    var mutualData: Int = 0
    
    func writeSync(inc: Int) { mutualData += inc }
    
    let loop = 0..<1_000
    
    func A() { writeSync(1); print("A - mutualData = \(mutualData)") }
    func B() { var i = 1.0; for _ in loop { i *= 2 }; writeSync(2); print("B - mutualData = \(mutualData)") }
    func C() { writeSync(3); print("C - mutualData = \(mutualData)") }
    func D() { writeSync(4); print("D - mutualData = \(mutualData)") }
    
    let priority = DISPATCH_QUEUE_PRIORITY_DEFAULT
    let backgroundThread = dispatch_get_global_queue(priority, 0)
    A()
    dispatch_async(backgroundThread) { B() }
    C()
    D()
  }
  
  private func mutualDataWithMutex() {
    print("\nDemo mutual data with mutex")
    var mutualData: Int = 0
    
    let lockedThread = dispatch_queue_create("dev.ethanify.me.locked_queue", nil)
    func writeSync(inc: Int) { dispatch_sync(lockedThread) { mutualData += inc } }
    
    let loop = 0..<10_000
    
    func A() { writeSync(1); print("A - mutualData = \(mutualData)") }
    func B() { var i = 1.0; for _ in loop { i *= 2 }; writeSync(2); print("B - mutualData = \(mutualData)") }
    func C() { writeSync(3); print("C - mutualData = \(mutualData)") }
    func D() { writeSync(4); print("D - mutualData = \(mutualData)") }
    
    let priority = DISPATCH_QUEUE_PRIORITY_DEFAULT
    let backgroundThread = dispatch_get_global_queue(priority, 0)
    A()
    dispatch_async(backgroundThread) { B() }
    C()
    D()
  }
  
  private func performWithDelay() {
    print("\nDemo perform with delay")
    let delay = 3.0           // 3 seconds
    let dispatchTime = dispatch_time(DISPATCH_TIME_NOW, Int64(delay * Double(NSEC_PER_SEC)))
    
    print("Start waiting")
    dispatch_after(dispatchTime, dispatch_get_main_queue()) { 
      print("Perform after \(delay) seconds")
      print("End waiting")
    }
  }
  
  private func queuedTasks() {
    print("\nDemo tasks with queue")
    func invokeTask(order: Int, inQueue queueNumber: Int) -> NSOperation {
      let operation = NSOperation()
      operation.queuePriority = .Normal
      operation.qualityOfService = .Background
      
      operation.completionBlock = { print("\t[Queue #\(queueNumber)] Task #\(order) completed!") }
      return operation
    }
    
    func createQueue(number: Int, taskOrders: Int...) -> NSOperationQueue {
      let queue = NSOperationQueue()
      queue.maxConcurrentOperationCount = 1
      
      print("Start queue #\(number)")
      taskOrders.forEach { queue.addOperation(invokeTask($0, inQueue: number)) }
      return queue
    }
    
    createQueue(1, taskOrders: 1, 5, 6, 7, 8)
    createQueue(2, taskOrders: 2, 9, 10)
    createQueue(3, taskOrders: 3)
    createQueue(4, taskOrders: 4)
  }
}