records = [
  [1, "Robert", "Baratheon", "Decreased King", 0],
  [2, "Jofrey", "Baratheon", "King of Westeros", 50000],
  [3, "Tyrion", "Lannister", "Hand of the King", 10000],
  [4, "Eddard", "Stark", "Lord of Winterfell", 9000],
  [5, "Daenerys", "Targaryen", "Mother of Dragons", 8000],
  [6, "Jon", "Snow", "Bastard of Lord Stark", 7000],
  [7, "Cersei", "Lannister", "Queen of Westeros", 8500],
  [8, "Khal", "Drogo", "Khal of Dothraki", 6000],
  [9, "Petyr", "Baelish", "Littlefinger", 7500],
  [10, "Varys", "of Lys", "The Spider", 7500]
]

all_salaries = records.map {|r| r.last}
puts(all_salaries)

total_pays = all_salaries.reduce(:+)
puts(total_pays)

good_pays = records.select {|r| r.last >= 8000}
names = good_pays.map {|r| "#{r[1]} #{r[2]}"}

good_pay_names = names.reduce(:+)
puts(good_pay_names)

good_pay_names = names.reduce {|temp, name|
  temp.empty? ? name : temp + ", #{name}"
}
puts(good_pay_names)

full_names = records.map {|r| [r[1], r[2]]}
last_name_groups = full_names.reduce({}) {|temp, full_name|
  first_name, last_name = full_name
  temp[last_name] ||= []
  temp[last_name] << first_name
  temp
}

flat_records = records.flatten
puts(flat_records)