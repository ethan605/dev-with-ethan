//: Playground - noun: a place where people can play

import Foundation

// "Id", "First name", "Last name", "Title", "Salary"
let records : [[AnyObject]] = [
  [1, "Robert", "Baratheon", "Decreased King", 0],
  [2, "Jofrey", "Baratheon", "King of Westeros", 50000],
  [3, "Tyrion", "Lannister", "Hand of the King", 10000],
  [4, "Eddard", "Stark", "Lord of Winterfell", 9000],
  [5, "Daenerys", "Targaryen", "Mother of Dragons", 8000],
  [6, "Jon", "Snow", "Bastard of Lord Stark", 7000],
  [7, "Cersei", "Lannister", "Queen of Westeros", 8500],
  [8, "Khal", "Drogo", "Khal of Dothraki", 6000],
  [9, "Petyr", "Baelish", "Littlefinger", 7500],
  [10, "Varys", "of Lys", "The Spider", 7500]
]

let allSalaries = records.map { $0.last as! Int }
print(allSalaries)

let totalPays = allSalaries.reduce(0, combine: +)
print(totalPays)

let totalPays2 = allSalaries.reduce(0) { (temp, salary) in
  print("Reduce step: temp = \(temp), salary = \(salary)")
  return temp + salary
}
print("Total pays = \(totalPays)")

let goodPays = records.filter { ($0.last as! Int) >= 8000 }
let names = goodPays.map { "\($0[1]) \($0[2])" }
print(names)

let goodPayNames = names.reduce("", combine: +)
print(goodPayNames)

let goodPayNames2 = names.reduce("") { (list, name) in
  if list == "" {
    return name
  } else {
    return list + ", \(name)"
  }
}
print(goodPayNames2)

let fullNames: [(String, String)] = records.map { ($0[1] as! String, $0[2] as! String) }
let lastNameGroups = fullNames.reduce([String: [String]]()) { (temp: [String: [String]], fullName) in
  var temp = temp
  
  let (firstName, lastName) = fullName
  if temp[lastName] == nil { temp[lastName] = [String]() }
  
  temp[lastName]!.append(firstName)
  return temp
}
print(lastNameGroups)

let flatRecords = records.flatMap { $0 }
print(flatRecords)