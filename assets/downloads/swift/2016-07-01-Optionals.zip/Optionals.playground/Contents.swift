//: Playground - noun: a place where people can play

import Foundation

var originalInt: Int = 0

var optionalInt: Int? = nil
print(optionalInt)
"optionalInt = \(optionalInt)"

// Fatal error
//print(optionalInt!)
//"optionalInt = \(optionalInt!)"

optionalInt = 10
print(optionalInt)
"optionalInt = \(optionalInt)"

print(optionalInt!)
"optionalInt = \(optionalInt!)"

var autoUnwrap: Int! = nil
print(autoUnwrap ?? "")

autoUnwrap = 10
print(autoUnwrap)
"optionalInt = \(autoUnwrap)"

optionalInt = nil
optionalInt = 10

if let checkedInt = optionalInt {
  print(checkedInt)
  "checkedInt = \(checkedInt)"
} else {
  print("nil")
  "no value for checkedInt"
}

extension Int {
  func add(otherNum: Int) -> Int {
    return self + otherNum
  }
  
  func multiply(otherNum: Int) -> Int {
    return self * otherNum
  }
  
  func divide(otherNum: Int) -> Int? {
    if otherNum == 0 {
      return nil
    }
    
    return self / otherNum
  }
}

var number: Int = 10

number.add(2).multiply(5)

var result = number.divide(0)

if result != nil {
  result = result!.add(10)
}

number = 10
number.divide(0)?.add(10).multiply(5)
number.divide(3)?.add(10).multiply(5)

var json: [String: NSObject?] = [
  "array": NSArray(),
  "dict": NSDictionary(),
  "nil": nil
]

let optionalArray = json["array"] as? NSArray
let unwrappedArray = json["array"] as! NSArray

// Error
//json["nil"] as! NSArray