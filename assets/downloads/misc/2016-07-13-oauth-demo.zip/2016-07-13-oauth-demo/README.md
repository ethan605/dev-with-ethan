# oauth-demo
OAuth demonstration in Ruby, using Sinatra &amp; Omniauth gems
